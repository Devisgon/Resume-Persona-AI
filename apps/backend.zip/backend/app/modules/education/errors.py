class EducationError(Exception):
    pass
