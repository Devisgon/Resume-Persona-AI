"""Education module."""
