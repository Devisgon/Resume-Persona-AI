class EducationRepository:
    pass
