class EducationService:
    pass
