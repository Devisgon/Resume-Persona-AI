class ExperienceError(Exception):
    pass
