"""Skills module."""
