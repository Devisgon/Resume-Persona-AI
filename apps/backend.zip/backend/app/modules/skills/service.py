class SkillsService:
    pass
