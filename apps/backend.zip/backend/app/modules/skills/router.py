from fastapi import APIRouter

router = APIRouter(prefix="/skills", tags=["Skills"])
