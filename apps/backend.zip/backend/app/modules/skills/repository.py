class SkillsRepository:
    pass
