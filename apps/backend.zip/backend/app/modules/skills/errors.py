class SkillsError(Exception):
    pass
