class ProjectsError(Exception):
    pass
