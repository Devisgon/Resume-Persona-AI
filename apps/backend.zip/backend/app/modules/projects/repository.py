class ProjectsRepository:
    pass
