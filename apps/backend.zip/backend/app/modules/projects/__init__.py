"""Projects module."""
