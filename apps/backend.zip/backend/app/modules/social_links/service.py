class SocialLinksService:
    pass
