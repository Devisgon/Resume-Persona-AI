"""Social links module."""
