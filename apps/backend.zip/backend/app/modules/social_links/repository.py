class SocialLinksRepository:
    pass
