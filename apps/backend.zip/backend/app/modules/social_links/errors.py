class SocialLinksError(Exception):
    pass
