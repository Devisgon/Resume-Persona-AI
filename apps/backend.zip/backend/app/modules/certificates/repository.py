class CertificatesRepository:
    pass
