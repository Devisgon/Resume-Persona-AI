class CertificatesError(Exception):
    pass
