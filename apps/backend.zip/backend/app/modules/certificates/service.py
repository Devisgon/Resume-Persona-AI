class CertificatesService:
    pass
